# 🔧 RENDERERS.JS PRACTICAL PATCHES

This file shows you **exactly** what to change in `renderers.js` with copy-paste ready code.

---

## STEP 1: Add Helper Functions at the Top

**Location**: Right after `const renderers = {` (around line 3)

**Add this code**:

```javascript
const renderers = {

    // ✅ ADD THESE HELPER FUNCTIONS HERE:
    
    // Helper to get value from state instead of DOM
    getStateValue(category, field, defaultValue = '') {
        if (state.configData[category] && state.configData[category][field] !== undefined) {
            return state.configData[category][field];
        }
        return defaultValue;
    },

    // Create input with state binding
    createStateInput(id, category, field, placeholder = '', type = 'text') {
        const value = this.getStateValue(category, field, '');
        const escaped = value.toString().replace(/"/g, '&quot;');
        return `<input type="${type}" 
                       id="${id}" 
                       class="form-input" 
                       value="${escaped}" 
                       placeholder="${placeholder}"
                       oninput="state.updateField('${category}', '${field}', this.value)">`;
    },

    // Create textarea with state binding
    createStateTextarea(id, category, field, placeholder = '', rows = 4) {
        const value = this.getStateValue(category, field, '');
        return `<textarea 
                    id="${id}" 
                    class="form-textarea" 
                    rows="${rows}" 
                    placeholder="${placeholder}"
                    oninput="state.updateField('${category}', '${field}', this.value)">${value}</textarea>`;
    },

    // Create select with state binding
    createStateSelect(id, category, field, options) {
        const currentValue = this.getStateValue(category, field, options[0].value);
        const optionsHtml = options.map(opt => 
            `<option value="${opt.value}" ${currentValue === opt.value ? 'selected' : ''}>${opt.label}</option>`
        ).join('');
        
        return `<select id="${id}" 
                        class="form-input" 
                        onchange="state.updateField('${category}', '${field}', this.value)">
                    ${optionsHtml}
                </select>`;
    },

    // ========================================
    // STEP 1: SETUP (Theme & Basic Config)
    // ========================================
    renderSetupStep() {
        // ... existing code continues ...
```

---

## STEP 2: Update Background Image Input

**Find** (around line 57):
```javascript
<input type="text" id="theme_bg" class="form-input" placeholder="assets/bg.png or Leave empty for default" value="" data-preview="prev_theme_bg">
```

**Replace with**:
```javascript
${this.createStateInput('theme_bg', 'theme', 'backgroundImage', 'assets/bg.png or Leave empty for default')}
```

**Full context**:
```javascript
<div>
    <label class="block text-sm font-bold text-gray-600 mb-2">Custom Background Image</label>
    <div class="flex gap-2 items-center">
        <img id="prev_theme_bg" src="${this.getStateValue('theme', 'backgroundImage', '')}" 
             class="img-preview-mini w-12 h-12 object-cover rounded-lg shadow-sm ${this.getStateValue('theme', 'backgroundImage') ? '' : 'hidden'}"">
        ${this.createStateInput('theme_bg', 'theme', 'backgroundImage', 'assets/bg.png or Leave empty for default')}
        <label class="cursor-pointer bg-white border border-gray-200 rounded-xl px-4 py-2 flex items-center hover:bg-gray-50 transition-colors shadow-sm">
            <span class="material-symbols-outlined text-gray-500">upload_file</span>
            <input type="file" class="hidden" accept="image/*" data-target="theme_bg">
        </label>
    </div>
</div>
```

---

## STEP 3: Update Background Color Inputs

**Find** (around line 68-69):
```javascript
<input type="color" id="theme_color_picker" class="w-12 h-11 rounded-lg border-gray-200" value="#F5E6D3" oninput="document.getElementById('theme_color').value = this.value">
<input type="text" id="theme_color" class="form-input" value="#F5E6D3">
```

**Replace with**:
```javascript
<input type="color" 
       id="theme_color_picker" 
       class="w-12 h-11 rounded-lg border-gray-200" 
       value="${this.getStateValue('theme', 'backgroundColor', '#F5E6D3')}" 
       oninput="state.updateField('theme', 'backgroundColor', this.value); document.getElementById('theme_color').value = this.value">
<input type="text" 
       id="theme_color" 
       class="form-input" 
       value="${this.getStateValue('theme', 'backgroundColor', '#F5E6D3')}"
       oninput="state.updateField('theme', 'backgroundColor', this.value); document.getElementById('theme_color_picker').value = this.value">
```

---

## STEP 4: Update Font Selects

**Find** (around line 76-84):
```javascript
<select id="theme_font_display" class="form-input">
    <option value="Playfair Display, serif">Playfair Display (Vintage)</option>
    <option value="Great Vibes, cursive">Great Vibes (Romantic & Flowy)</option>
    <!-- ... more options ... -->
</select>
```

**Replace with**:
```javascript
${this.createStateSelect('theme_font_display', 'theme', 'fontDisplay', [
    { value: 'Playfair Display, serif', label: 'Playfair Display (Vintage)' },
    { value: 'Great Vibes, cursive', label: 'Great Vibes (Romantic & Flowy)' },
    { value: 'Dancing Script, cursive', label: 'Dancing Script (Elegant Script)' },
    { value: 'Sacramento, cursive', label: 'Sacramento (Thin & Minimalist)' },
    { value: 'Cinzel, serif', label: 'Cinzel (Luxury / Classic)' },
    { value: 'Lobster, cursive', label: 'Lobster (Retro / Fun)' },
    { value: 'Pacifico, cursive', label: 'Pacifico (Playful)' },
    { value: 'Montserrat, sans-serif', label: 'Montserrat (Bold Modern)' },
    { value: 'Inter, sans-serif', label: 'Inter (Clean)' }
])}
```

**Same for Secondary Font** (around line 89-95):
```javascript
${this.createStateSelect('theme_font_sans', 'theme', 'fontSans', [
    { value: 'Poppins, sans-serif', label: 'Poppins (Smooth & Modern)' },
    { value: 'Inter, sans-serif', label: 'Inter (Standard)' },
    { value: 'Cormorant Garamond, serif', label: 'Cormorant Garamond (Fine Italic)' },
    { value: 'Roboto, sans-serif', label: 'Roboto (Clean)' },
    { value: 'Courier New, monospace', label: 'Courier New (Old School)' }
])}
```

---

## STEP 5: Update Particles Select

**Find** (around line 100-106):
```javascript
<select id="theme_particles" class="form-input">
    <option value="none">None (Clean)</option>
    <option value="hearts">Hearts & Petals (Romantic / Cute)</option>
    <!-- ... -->
</select>
```

**Replace with**:
```javascript
${this.createStateSelect('theme_particles', 'theme', 'particles', [
    { value: 'none', label: 'None (Clean)' },
    { value: 'hearts', label: 'Hearts & Petals (Romantic / Cute)' },
    { value: 'stars', label: 'Twinkling Stars (Midnight / Magic)' },
    { value: 'dust', label: 'Vintage Dust (Nostalgic / Paper)' },
    { value: 'bubbles', label: 'Floating Bubbles (Modern / Dreamy)' }
])}
```

---

## STEP 6: Update Navigation Checkboxes

**Find** (around line 112-118):
```javascript
<input type="checkbox" id="show_indicator" class="..." checked>
<!-- ... -->
<input type="checkbox" id="enable_swipe" class="..." checked>
```

**Replace with**:
```javascript
<input type="checkbox" 
       id="show_indicator" 
       class="form-checkbox h-5 w-5 text-rose-600 rounded focus:ring-rose-500" 
       ${this.getStateValue('navigation', 'showPageIndicator', true) ? 'checked' : ''}
       onchange="state.updateField('navigation', 'showPageIndicator', this.checked)">

<!-- ... -->

<input type="checkbox" 
       id="enable_swipe" 
       class="form-checkbox h-5 w-5 text-rose-600 rounded focus:ring-rose-500" 
       ${this.getStateValue('navigation', 'enableSwipe', true) ? 'checked' : ''}
       onchange="state.updateField('navigation', 'enableSwipe', this.checked)">
```

---

## STEP 7: Update Login Inputs

**Find** (around line 132-148):
```javascript
<input type="text" id="password" class="form-input" value="cintaislam1234512345">
<input type="text" id="collectionText" class="form-input" value="For you, Always">
<input type="text" id="p1_title" class="form-input" value="Key to My Heart">
<input type="text" id="p1_instr" class="form-input" value="Enter the secret password">
```

**Replace with**:
```javascript
${this.createStateInput('password', 'login', 'password', 'Enter password')}
${this.createStateInput('collectionText', 'login', 'collectionText', 'Collection text')}
${this.createStateInput('p1_title', 'login', 'title', 'Login page title')}
${this.createStateInput('p1_instr', 'login', 'instruction', 'Login instruction')}
```

---

## STEP 8: Update Countdown Inputs

**Find** (around line 151-156):
```javascript
<input type="datetime-local" id="count_date" class="form-input border-rose-200" value="2026-02-14T22:00">
<input type="text" id="count_finish" class="form-input border-rose-200" value="It's Time! ❤️">
```

**Replace with**:
```javascript
<input type="datetime-local" 
       id="count_date" 
       class="form-input border-rose-200" 
       value="${this.getStateValue('countdown', 'targetDate', '2026-02-14T22:00').substring(0, 16)}"
       oninput="state.updateField('countdown', 'targetDate', new Date(this.value).toISOString())">

${this.createStateInput('count_finish', 'countdown', 'finishMessage', 'Finish message')}
```

---

## STEP 9: Update Greeting Inputs

**Find** (around line 309-336):
```javascript
<input type="text" id="greet_title" class="form-input" value="${val('greet_title') || \"Happy Valentine's Day\"}">
<textarea id="greet_msg" ... >${val('greet_msg') || 'You mean the world to me'}</textarea>
<input type="text" id="greet_img" ... value="${val('greet_img')}" ...>
<input type="text" id="greet_signature" ... value="${val('greet_signature') || 'With Love'}" ...>
<input type="text" id="greet_footer" ... value="${val('greet_footer') || 'For you, Always'}">
```

**Replace with**:
```javascript
${this.createStateInput('greet_title', 'greeting', 'title', "Happy Valentine's Day")}
${this.createStateTextarea('greet_msg', 'greeting', 'message', 'Your heartfelt message', 5)}
${this.createStateInput('greet_img', 'greeting', 'imageSrc', 'assets/photo.jpg')}
${this.createStateInput('greet_signature', 'greeting', 'signature', 'With Love')}
${this.createStateInput('greet_footer', 'greeting', 'footerText', 'For you, Always')}
```

---

## STEP 10: Update Customer Name

**Find customer name input** (check where it appears in your file):
```javascript
<input type="text" id="cust_name" class="form-input" value="">
```

**Replace with**:
```javascript
${this.createStateInput('cust_name', 'metadata', 'customerName', 'Your name or business')}
```

---

## STEP 11: Remove the `val()` Helper Function

**Find and DELETE** (usually near the top of renderSetupStep):
```javascript
const val = (id) => {
    const el = document.getElementById(id);
    return el ? el.value : '';
};
```

This function is no longer needed since we're using `getStateValue()` instead!

---

## VERIFICATION CHECKLIST

After making all changes, verify:

1. ✅ All inputs have `oninput` or `onchange` handlers calling `state.updateField()`
2. ✅ All input values are set using `getStateValue()` or helper functions
3. ✅ No `document.getElementById()` calls for reading values
4. ✅ The `val()` helper function is removed
5. ✅ All helper functions are added at the top of `renderers` object

---

## TESTING

1. Open admin panel
2. Clear localStorage: `localStorage.clear(); location.reload();`
3. Fill Setup step with custom values
4. Click "Next" to go to Page Manager
5. Click "Back" to return to Setup
6. **Verify**: All your custom values are still there! ✅

---

## TROUBLESHOOTING

**Issue**: "state.updateField is not a function"
**Fix**: Make sure you replaced `state.js` with the fixed version first!

**Issue**: Values not persisting
**Fix**: Check console for errors. Ensure all inputs have `oninput` handlers.

**Issue**: Preview not updating
**Fix**: The auto-save in `app.js` should handle this. Check if `state.syncToPreview()` is called.

**Issue**: Syntax errors
**Fix**: Make sure you're using backticks (\`) for template literals, not quotes.

---

## QUICK COPY-PASTE TEMPLATE

For any new input you add later:

```javascript
// Text input:
${this.createStateInput('input_id', 'category', 'field', 'placeholder')}

// Textarea:
${this.createStateTextarea('textarea_id', 'category', 'field', 'placeholder', 5)}

// Select:
${this.createStateSelect('select_id', 'category', 'field', [
    { value: 'option1', label: 'Option 1' },
    { value: 'option2', label: 'Option 2' }
])}

// Checkbox:
<input type="checkbox" 
       id="checkbox_id" 
       ${this.getStateValue('category', 'field', true) ? 'checked' : ''}
       onchange="state.updateField('category', 'field', this.checked)">

// Image preview:
<img id="preview_id" 
     src="${this.getStateValue('category', 'field', '')}" 
     class="${this.getStateValue('category', 'field') ? '' : 'hidden'}">
```

That's it! Your wizard will now preserve all data perfectly. 🎉

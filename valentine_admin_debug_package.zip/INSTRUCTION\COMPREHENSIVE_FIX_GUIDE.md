# 🔧 COMPREHENSIVE FIX: Data Loss in Wizard Admin Panel

## Problem Summary

The wizard was losing data because:
1. ❌ **state.getConfig()** reads from DOM using `getElementById`
2. ❌ When wizard steps are hidden, those DOM elements **don't exist**
3. ❌ So `getConfig()` returns **empty values** for hidden steps
4. ❌ These empty values **overwrite** your previous work in localStorage

## Solution Overview

✅ **Make `state.configData` the absolute source of truth**
✅ **Update state immediately on input** (not on step change)
✅ **Read from state when rendering**, not from DOM
✅ **Never read from unmounted DOM elements**

---

## 📦 File Changes Required

### 1. Replace `/admin/js/state.js`

**Action**: Replace the entire file with `state_FIXED.js` (provided separately)

**Key changes**:
- ✅ `configData` now stores ALL form values (theme, login, countdown, etc.)
- ✅ `getConfig()` reads from `configData` instead of DOM
- ✅ New `updateField()` method for direct state updates
- ✅ `loadFromExistingConfig()` preserves data from `data.js`

---

### 2. Update `/admin/js/renderers.js`

Add these helper functions at the **top** of the file (after the `const renderers = {` line):

```javascript
// ✅ ADD THIS: Helper to get value from state instead of DOM
function getStateValue(category, field, defaultValue = '') {
    if (state.configData[category] && state.configData[category][field] !== undefined) {
        return state.configData[category][field];
    }
    return defaultValue;
}

// ✅ ADD THIS: Create input with state binding
function createStateInput(id, category, field, placeholder = '', type = 'text') {
    const value = getStateValue(category, field, '');
    const inputType = type === 'color' ? 'color' : 'text';
    return `<input type="${inputType}" 
                   id="${id}" 
                   class="form-input" 
                   value="${value}" 
                   placeholder="${placeholder}"
                   oninput="state.updateField('${category}', '${field}', this.value)">`;
}

// ✅ ADD THIS: Create textarea with state binding
function createStateTextarea(id, category, field, placeholder = '', rows = 4) {
    const value = getStateValue(category, field, '');
    return `<textarea 
                id="${id}" 
                class="form-textarea" 
                rows="${rows}" 
                placeholder="${placeholder}"
                oninput="state.updateField('${category}', '${field}', this.value)">${value}</textarea>`;
}
```

Now update the **renderSetupStep** function. Find the existing inputs and replace with state-bound versions:

```javascript
// ❌ OLD (around line 57):
<input type="text" id="theme_bg" class="form-input" placeholder="assets/bg.png or Leave empty for default" value="" data-preview="prev_theme_bg">

// ✅ NEW:
${createStateInput('theme_bg', 'theme', 'backgroundImage', 'assets/bg.png or Leave empty for default')}
```

```javascript
// ❌ OLD (around line 68-69):
<input type="color" id="theme_color_picker" class="w-12 h-11 rounded-lg border-gray-200" value="#F5E6D3" oninput="document.getElementById('theme_color').value = this.value">
<input type="text" id="theme_color" class="form-input" value="#F5E6D3">

// ✅ NEW:
<input type="color" 
       id="theme_color_picker" 
       class="w-12 h-11 rounded-lg border-gray-200" 
       value="${getStateValue('theme', 'backgroundColor', '#F5E6D3')}" 
       oninput="state.updateField('theme', 'backgroundColor', this.value); document.getElementById('theme_color').value = this.value">
<input type="text" 
       id="theme_color" 
       class="form-input" 
       value="${getStateValue('theme', 'backgroundColor', '#F5E6D3')}"
       oninput="state.updateField('theme', 'backgroundColor', this.value)">
```

```javascript
// ❌ OLD (around line 75-90):
<select id="theme_font_display" class="form-input">
    <option value="Playfair Display, serif">Playfair Display (Vintage)</option>
    <!-- ... more options ... -->
</select>

// ✅ NEW:
<select id="theme_font_display" 
        class="form-input" 
        onchange="state.updateField('theme', 'fontDisplay', this.value)">
    ${['Playfair Display, serif', 'Great Vibes, cursive', 'Dancing Script, cursive', 'Sacramento, cursive', 'Cinzel, serif', 'Lobster, cursive', 'Pacifico, cursive', 'Montserrat, sans-serif', 'Inter, sans-serif']
        .map(font => `<option value="${font}" ${getStateValue('theme', 'fontDisplay') === font ? 'selected' : ''}>${font.split(',')[0].trim()} (${font.includes('serif') ? 'Vintage' : font.includes('cursive') ? 'Romantic' : 'Modern'})</option>`)
        .join('')}
</select>
```

Similar updates for:
- `theme_font_sans` select
- `theme_particles` select  
- `password` input
- `collectionText` input
- `p1_title` input
- `p1_instr` input
- `count_date` input
- `count_finish` input
- `greet_title` input
- `greet_msg` textarea
- `greet_img` input
- `greet_signature` input
- `greet_footer` input
- `cust_name` input

**Complete pattern for all inputs**:

```javascript
// Text input pattern:
${createStateInput('input_id', 'category', 'field', 'placeholder')}

// Textarea pattern:
${createStateTextarea('textarea_id', 'category', 'field', 'placeholder', 5)}

// Select pattern:
<select id="select_id" 
        class="form-input" 
        onchange="state.updateField('category', 'field', this.value)">
    <option value="value1" ${getStateValue('category', 'field') === 'value1' ? 'selected' : ''}>Label 1</option>
    <option value="value2" ${getStateValue('category', 'field') === 'value2' ? 'selected' : ''}>Label 2</option>
</select>

// Checkbox pattern:
<input type="checkbox" 
       id="checkbox_id" 
       ${getStateValue('category', 'field', true) ? 'checked' : ''}
       onchange="state.updateField('category', 'field', this.checked)">
```

---

### 3. Update `/admin/js/app.js`

No major changes needed! The auto-save already works. But you can optionally improve it:

```javascript
// Around line 471-479 in setupAutoSave():

// ✅ IMPROVED VERSION:
setupAutoSave() {
    // No debounce needed - state updates happen immediately now
    // Just trigger sync to preview when inputs change
    const debouncedSync = utils.debounce(() => {
        state.syncToPreview();
    }, 500);

    document.addEventListener('input', debouncedSync);
    document.addEventListener('change', debouncedSync);
}
```

Also update `saveCurrentStep()` if you want to make it clearer:

```javascript
// Around line 222-226:
saveCurrentStep() {
    // State is already updated via input handlers
    // Just save to localStorage and sync
    state.save();
    state.syncToPreview();
}
```

---

## 🎯 Testing Checklist

After implementing the fixes:

1. **✅ Clear localStorage**: 
   ```javascript
   localStorage.clear();
   location.reload();
   ```

2. **✅ Test Setup Step**:
   - Change theme color → Go Next → Go Back
   - Verify color is **preserved**

3. **✅ Test Music Step**:
   - Add a song → Go Next → Go Back
   - Verify song is **still there**

4. **✅ Test Quiz Step**:
   - Add questions → Go Next → Go Back
   - Verify questions **remain**

5. **✅ Test Navigation**:
   - Fill all steps
   - Jump between steps multiple times
   - Verify **nothing is lost**

6. **✅ Test Save/Load**:
   - Complete wizard
   - Refresh page
   - Verify **all data loads back**

---

## 🔍 How It Works Now

### ❌ BEFORE (Broken Flow)

```
User types "Red" in Theme Color
    ↓
Value stored in DOM element only
    ↓
User clicks "Next"
    ↓
saveCurrentStep() called
    ↓
state.getConfig() tries to read from DOM
    ↓
Theme step is now HIDDEN (unmounted)
    ↓
getElementById('theme_color') returns NULL
    ↓
Value saved as EMPTY ""
    ↓
Data LOST ❌
```

### ✅ AFTER (Fixed Flow)

```
User types "Red" in Theme Color
    ↓
oninput triggers: state.updateField('theme', 'backgroundColor', 'Red')
    ↓
Value immediately stored in state.configData.theme.backgroundColor
    ↓
User clicks "Next"
    ↓
saveCurrentStep() called
    ↓
state.getConfig() reads from state.configData (not DOM)
    ↓
Value read: state.configData.theme.backgroundColor = "Red"
    ↓
Data SAVED ✅
    ↓
When user goes back:
    ↓
renderSetupStep() pulls value from state.configData
    ↓
Input shows "Red" ✅
```

---

## 📋 Complete Input Mapping Reference

Here's every input that needs to be updated:

| Input ID | Category | Field | Type |
|----------|----------|-------|------|
| theme_bg | theme | backgroundImage | text |
| theme_color | theme | backgroundColor | text |
| theme_font_display | theme | fontDisplay | select |
| theme_font_sans | theme | fontSans | select |
| theme_particles | theme | particles | select |
| show_indicator | navigation | showPageIndicator | checkbox |
| enable_swipe | navigation | enableSwipe | checkbox |
| password | login | password | text |
| collectionText | login | collectionText | text |
| p1_title | login | title | text |
| p1_instr | login | instruction | text |
| count_date | countdown | targetDate | datetime-local |
| count_finish | countdown | finishMessage | text |
| greet_title | greeting | title | text |
| greet_msg | greeting | message | textarea |
| greet_img | greeting | imageSrc | text |
| greet_signature | greeting | signature | text |
| greet_footer | greeting | footerText | text |
| cust_name | metadata | customerName | text |

---

## 🚨 Common Pitfalls to Avoid

1. **DON'T** read from DOM in `getConfig()` - always read from `state.configData`
2. **DON'T** wait for "Save" button - update state on every `oninput`
3. **DON'T** use `document.getElementById()` to get current values - use `getStateValue()`
4. **DO** use `state.updateField()` in all input `oninput` handlers
5. **DO** use `state.updatePageData()` for page-specific data (music, quiz, etc.)

---

## 💡 Example: Complete Input Fix

**Before** (reads from DOM, loses data):
```html
<input type="text" 
       id="password" 
       class="form-input" 
       value="cintaislam1234512345">
```

```javascript
// In getConfig():
login: {
    password: document.getElementById('password')?.value || '' // ❌ Returns empty if hidden
}
```

**After** (reads from state, preserves data):
```html
<input type="text" 
       id="password" 
       class="form-input" 
       value="${getStateValue('login', 'password', 'cintaislam1234512345')}"
       oninput="state.updateField('login', 'password', this.value)">
```

```javascript
// In getConfig():
login: this.configData.login // ✅ Always returns correct values
```

---

## 🎉 Benefits After Fix

✅ **No data loss** when navigating between steps
✅ **Instant updates** to preview as you type
✅ **Persistent state** across page refreshes
✅ **Source of truth** is always `state.configData`
✅ **Works with existing** save/load system
✅ **No breaking changes** to wizard flow

---

## 📝 Summary of Changes

| File | Lines Changed | Type of Change |
|------|---------------|----------------|
| state.js | 1-418 (entire file) | Complete rewrite - state as source of truth |
| renderers.js | ~50-300 | Add helper functions + update all inputs |
| app.js | ~471-479 (optional) | Minor improvement to auto-save |

**Total complexity**: Medium
**Risk level**: Low (backwards compatible)
**Testing time**: 15 minutes

---

## 🔗 Files Provided

1. **state_FIXED.js** - Complete replacement for `state.js`
2. **This guide** - Implementation instructions

---

## ❓ FAQ

**Q: Will this break existing saved data?**
A: No. The new code loads from existing `data.js` and localStorage correctly.

**Q: Do I need to update ALL inputs at once?**
A: Recommended, but you can do it incrementally. Start with theme inputs to test.

**Q: What if I have custom page types?**
A: Follow the same pattern: use `state.updatePageData()` for page-specific data.

**Q: How do I debug if something goes wrong?**
A: Check `state.configData` in console: `console.log(state.configData)`

---

## 🎯 Quick Start (TL;DR)

1. Replace `/admin/js/state.js` with the provided `state_FIXED.js`
2. Add helper functions to top of `/admin/js/renderers.js`
3. Update all inputs to use `state.updateField()` in `oninput` handlers
4. Test by filling data, navigating steps, verifying persistence

That's it! Your data will never be lost again. 🎉
